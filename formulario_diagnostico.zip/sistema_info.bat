@echo off
echo Coletando informacoes do sistema...
echo ------------------------------------

:: ID da máquina (nome do computador)
echo ID da Maquina: %COMPUTERNAME%

:: Memória RAM em GB (usando WMIC)
for /f "skip=1" %%i in ('wmic computersystem get TotalPhysicalMemory') do (
    set memBytes=%%i
    goto convertMem
)

:convertMem
set /a memGB=%memBytes:~0,-9%
echo Memoria RAM: %memGB% GB

:: Versão do Google Chrome (tentando via arquivo)
echo Verificando versao do Google Chrome...
for /f "tokens=3 delims= " %%a in ('reg query "HKCU\Software\Google\Chrome\BLBeacon" /v version 2^>nul') do (
    echo Versao do Chrome: %%a
    goto fimChrome
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    "%LocalAppData%\Google\Chrome\Application\chrome.exe" --version
    goto fimChrome
)
if exist "C:\Program Files\Google\Chrome\Application\chrome.exe" (
    "C:\Program Files\Google\Chrome\Application\chrome.exe" --version
    goto fimChrome
)
if exist "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" (
    "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" --version
    goto fimChrome
)
echo Chrome nao encontrado

:fimChrome

:: Verifica se Chrome é 64 bits
echo Verificando arquitetura do Chrome...
if exist "C:\Program Files (x86)\Google\Chrome" (
    echo Chrome 32 bits
) else if exist "C:\Program Files\Google\Chrome" (
    echo Chrome 64 bits
) else (
    echo Chrome nao encontrado
)

:: Versão do Windows
systeminfo | findstr /B /C:"OS Name" /C:"OS Version"

pause
